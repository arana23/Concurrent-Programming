//I pledge my honor that I have abided by the Stevens Honor System - Aparajita Rana

public class Swapper implements Runnable {
    private int offset;
    private Interval interval;
    private String content;
    private char[] buffer;

    public Swapper(Interval interval, String content, char[] buffer, int offset) {
        this.offset = offset;
        this.interval = interval;
        this.content = content;
        this.buffer = buffer;
    }

    @Override
    //will write to the buffer given its Interval
    public void run() {
        // TODO: Implement me!
        for(int x = offset; x <= (interval.getY() - interval.getX())+offset; x++) {
            //System.out.println(interval.getX()+(x-offset));
            buffer[x] = content.charAt(interval.getX()+(x-offset));
            }
    }
}